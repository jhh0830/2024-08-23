package com.kh.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import com.kh.model.vo.Member;
/*
 * Dao (Data Access Object)
 * Controller 를 통해서 호출된 기능을 수행하기 위해
 * 데이터가 담겨있는 외부매체인 DB 에 직접적으로 접근한 후
 * 해당 SQL 문을 실행하고 결과를 받아주는 부분
 * > 즉, JDBC 과정을 처리하는 부분
 * 
 */

/*
 * * JDBC 용 객체
 * - Connection : DB 의 연결정보를 담고 있는 객체
 * 				  Connection 객체가 생성되는 순간
 * 				  해당 DB 와의 연결이 이루어짐
 * - (Prepared)Statement : 해당 DB 에 SQL문을 전달하고
 * 							실행한 후 결과를 받아내는 객체 
 * - ResultSet : 내가 만일 실행한 SQL문이 SELECT 문일 경우
 * 				 조회된 결과들이 담겨있는 객체
 * * JDBC 처리 순서
 * 1) JDBC Driver 등록 
 * : 해당 DBMS 가 제공하고 있는 클래스 등록
 * 2) Connection 객체 생성
 * : 접속하고자 하는 DB 정보를 입력해서 DB 에 접속하면서 생성
 *   (Connection 객체 생성 == DB 에 접속)
 * 3) Statement 객체 생성
 * : Connection 객체를 이용해서 생성
 * 4) SQL 문 전달하면서 실행
 * : Statement 객체를 이용해서 SQL 문 실행
 *   - SELECT 문의 경우 : executeQuery 메소드를 이용해서 실행
 *   - DML문의 경우 : executeUpdate 메소드를 이용해서 실행
 *   (INSERT, UPDATE, DELETE 문)
 * 5) 결과 받기
 *  - SELECT 문의 경우 : ResultSet 객체 
 *  (조회된 데이터들이 담겨있음) 로 받기
 *  => 6_1)
 *  - DML 문(INSERT, UPDATE, DELETE 문)의 경우 :  int (처리된 행의 갯수)로 받기 
 *  => 6_2)
 * 6_1) ResultSet 에 담겨있는 조회된 데이터들을
 *      하나씩 뽑아서 VO 객체에 담기
 * 6_2) 트랜잭션 처리 (성공 시 COMMIT, 실패 시 ROLLBACK)
 * 7) 다 쓴 JDBC 용 자원들을 반납 (close)
 * : 단, 생성 순서의 역순으로 반납하기
 * 8) Controller 로 결과 반환
 *   - SELECT 문의 경우 : 6_1) 에서 만들어진 결과
 *   - DML 문(INSERT, UPDATE, DELETE 문)의 경우 : int (처리된 행의 갯수)
 *        		
 * ** Statement 특징 : 완성된 SQL문을 실행!!
 */
public class MemberDao {

	/**
	 * 사용자가 회원 추가 요청 시 입력했던 값들을 가지고
	 * MEMBER 테이블에 INSERT 문을 실행해주는 메소드
	 * @param m => 사용자가 입력했던 아이디 ~ 취미 까지의 값들이 담겨있는
	 * 			   Member 객체
	 * @return => Insert 된 행의 갯수
	 */
	public int insertMember(Member m) {
		// insert 문 => 처리된 행의 갯수 = > 트랜잭션 처리
		
		// 0)  필요한 변수들 먼저 셋팅
		int result = 0; // 처리된 행의 갯수를 담아줄 변수
		 Connection conn = null; // 접속할 DB 의 정보를 담을 변수
		 Statement stmt = null; // SQL 문을 전달 후 실행할 용도의 변수
		// 실행할 SQL 문 (단, 완성된 형태로 만들 것)
		// 끝에 세미콜론 (;) 이 있으면 안됨
		/*
		INSERT INTO MEMBER VALUES(SEQ_USERNO.NEXTVAL
                , 'XXX'
                , 'XXX'
                , 'XXX'
                , 'X'
                , XX
                , 'XXXX'
                , 'XXXX'
                , 'XXXX'
                , 'XXX'
                , DEFAULT);
                */
		String sql = "INSERT INTO MEMBER VALUES(SEQ_USERNO.NEXTVAL"
											+ ", '"+ m.getUserId() +"'"
											+ ", '"+ m.getUserPwd() +"'"
											+ ", '"+ m.getUserName() +"'"
											+ ", '"+ m.getGender() +"'"
											+ ", " + m.getAge() 
											+ ", '"+ m.getEmail() +"'"
											+ ", '"+ m.getPhone() +"'"
											+ ", '"+ m.getAddress() +"'"
											+ ", '"+ m.getHobby() +"'"
											+ ", DEFAULT)";
		
		try {

			//System.out.println(sql);
			
			// 1) JDBC Driver 등록
			// [ 표현법 ]
			// Class.forName("oracle.jdbc.driver.OracleDriver");
			// > ojdbc6.jar 에서제공하고있는
			//   oracle.jdbc.driver 패키지의
			//   OracleDriver 클래스를 등록해서 가져다 쓰겠다는 의미
			// > 풀클래스명에 오타가 있거나, ojdbc6.jar 연동이 안되어있다면
			//   ClassNotFoundException 예외 발생
			
			Class.forName("oracle.jdbc.driver.OracleDriver");
			
			// 2) Connection 객체 생성
			// DB 접속과 관련된 정보들을 넘기면서 생성
			// [ 표현법 ]
			// Connection conn = DriverManager.getConnection(url주소, 계정명, 비번);
			// Connection 객체가 생성되는 순간 해당 DB 에 접속됨!
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","JDBC","JDBC");
			
			// 이 시점 부터는 DB 에 접속이 된 것
			// 3) Statement 객체 생성
			// Connection 객체를 통해서 생성해야함
			// [ 표현법 ]
			// Statement stmt = conn.createStatement();
			stmt = conn.createStatement();
			
			// 4, 5) DB 에 완성된 SQL 문을 전달하면서 실행 후
			//       결과 받기
			//  - 실행할 SQL 문 종류 : INSERT 문
			//  - 호출해야할 메소드 : executeUpdate
			// [ 표현법 ]
			// int result = stmt.executeUpdate(sql문);
			// ResultSet rset = stmt.executeQuery(sql문);
			result = stmt.executeUpdate(sql);
			// > insert 가 제대로 되었다면 1
			//   insert 가 제대로 되지 않았다면 0
			
			// 6_2 트랜잭션 처리
			// 성공이면 COMMIT, 실패면 ROLLBACK
			if(result > 0) { // 성공했을 경우 (COMMIT)
				conn.commit();
			}else { // 실패했을 경우 (ROLLBACK)
				conn.rollback();
			}
			// 7) 다 쓴 JDBC 용 자원 반납
			// 반드시 해줘야 함!! 생성 순서의 역순으로!!
			// > finally 블럭에서 작성할 것!!
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			// 7) 다 쓴 JDBC 용 자원 반납
			// 반드시 해줘야 함!! 생성 순서의 역순으로!!
			try {
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}
		// 8) Controller 로 결과 반환
		return result;
	}// insertMember 메소드 끝
	
	/**
	 * 사용자가 회원 전체 조회 요청 시
	 * MEMBER 테이블에 SELECT * 구문을 실행하는 메소드
	 * @return => 조회된 회원들의 정보들이 담겨있는 리스트
	 */
	public ArrayList<Member> selectAll(){
		// select 문 => ResultSet 객체 (여러행 조회)
		// => ArrayList<Member>
		
		// 0) 필요한 변수들 먼저 셋팅
		ArrayList<Member> list = new ArrayList<>();
		// 조회된 결과를 뽑아서 담아 줄 변수(텅 빈 리스트)
		
	    Connection conn = null; // 접속할 DB 의 정보를 담는 변수
	    Statement stmt = null; // SQL 문을 전달하고 실행할 용도의 변수	    
		ResultSet rset = null; // select 문의 실행 결과를 담아낼 변수 
		
		// 실행할 SQL 문 (완성된 형태로, 세미콜론 x)
		String sql = "SELECT * FROM MEMBER";
		
		
		try {
			//1) JDBC Driver 등록
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//2) Connection 객체 생성
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","JDBC","JDBC");
			//3) Statement 객체 생성
		stmt = conn.createStatement();
		
		// 4,5) SQL 문 전달해서 실행 후 결과 받기
		// - 실행할 SQL 문 종류 : SELECT 문
		// - 호출할 메소드명 : executeQuery
		rset = stmt.executeQuery(sql);
		
		// 6_1) ... 
			
		} catch (ClassNotFoundException e) {
		
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
