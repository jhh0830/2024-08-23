package com.kh.run;

import com.kh.view.MemberView;

/*
 * * MVC 패턴
 * 
 * 역할에 따라 데이터관련(Model), 화면관련(View),요청처리관련(Controller)
 * 코드를 분류하여 개발하고 유지보수 하는 기법
 * 
 * M : Model 의 약자
 * 		데이터 관련한 코드를 담는 부분
 * 		데이터 담는 용도의 VO,
 * 		데이터가 보관된 외부매체에 직접적으로 접근하여
 * 		데이터가 입출력이 일어나는 DAO
 * V : View 의 약자
 * 		화면 관련한 코드를 담는 부분
 * 		CLI (Command Line Interface) 환경 상에서는 입력, 출력문으로
 * 		GUI (Graphic User Interface) 환경 상에서는 
 * 		html, css 등으로 구현함
 * C : Controller 의 약자
 * 		실제 요청을 받아 처리하는 코드를 담는 부분
 * 		주로 사용자로부터 전달받은 입력값들을 VO 객체로 가공하여
 * 		DAO 로 넘겨주는 용도
 * 		DAO 로 부터 전달받은 결과값에 따라 응답화면 (View) 을 지정
 * 		
 * * 코드의 흐름
 * Run --> MemberView --> MemberController --> MemberDao --> DB
 *     <--            <--                  <--           <--
 * 
 */
public class Run {

	public static void main(String[] args) {
		// 메인화면을 담당하는 메소드만 호출할 것
		//MemberView mv = new  MemberView();
		//mv.mainMenu();
		new MemberView().mainMenu();
		
		
	}

}
