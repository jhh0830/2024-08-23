package com.kh.view;

import java.util.Scanner;

import com.kh.controller.MemberController;

//View : 사용자가 보게 될 시각적인 요소 (화면)를 담당
//> 주로 입력문과 출력문을 이용해서 화면을 구성함
public class MemberView {
	
	/**
	 *  사용자가 보게 될 첫 화면 (메인화면)
	 */
	// 전역으로 다 쓸 수 있게끔 Scanner 객체를 필드로 생성
	private Scanner sc = new Scanner(System.in);
	
	
	// 전역으로 다 쓸수 있게끔 MemberController 객체를 필드로 생성
	private MemberController mc = new  MemberController();
	public void mainMenu() {
	
		while(true) {
			System.out.println("***** 회원 관리 프로그램 *****");
			System.out.println("1. 회원 추가");
			System.out.println("2. 회원 전체 조회");
			System.out.println("3. 회원 아이디로 검색");
			System.out.println("4. 회원 이름 키워드 검색");
			System.out.println("5. 회원 정보 변경");
			System.out.println("6. 회원 탈퇴");
			System.out.println("0. 프로그램 종료");
			System.out.println("-------------------------------------");
			
			System.out.print("이용할 메뉴 선택 : ");
			int menu =  sc.nextInt();
			sc.nextLine();
			
			switch(menu) {
			case 1 : 
				insertMember();
				
				break;
			case 2 :
				selectAll();
				break;
			case 3 :
				
				break;
			case 4 :
				System.out.println("4번 메뉴");
				break;
			case 5 : 
				System.out.println("5번 메뉴");
			    break;
			case 6 : 
				System.out.println("6번 메뉴");
				break;
			case 0 : 
				System.out.println("프로그램을 종료합니다.");
				return;
				default :
					System.out.println("번호를 잘못 입력했습니다. 다시 입력해 주세요.");
			
			}
			
			
		}
		
	}// mainMenu 메소드 끝
	
	
	/**
	 * 회원 추가용 화면
	 * 추가하고자 하는 회원의 정보를 입력받아서 추가 요청할 수 있는 화면
	 */
	public void insertMember() {
	
		System.out.println("--- 회원 추가 ---");
		
		// 회원 추가 요청 시 필요한 데이터들
		// 아이디, 비번, 이름, 성별, 나이, 이메일, 전화번호, 주소, 취미
		// 아이디, 비번, 이름은 필수입력!!
		
		System.out.print("* 아이디 : ");
		String userId = sc.nextLine();
		
		System.out.print("* 비밀번호 : ");
		String userPwd = sc.nextLine();
		
		System.out.print("* 이름 : ");
		String userName = sc.nextLine();
		
		System.out.print("성별 (M/Y) : ");
		String gender = sc.nextLine().toUpperCase(); // "m" / "f"
		
		System.out.print("나이 : ");
		int age = sc.nextInt();
		sc.nextLine();
		
		System.out.print("이메일 : ");
		String email = sc.nextLine();
		
		System.out.print("전화번호 (숫자만) : ");
		String phone = sc.nextLine();
		
		System.out.print("주소 : ");
		String address = sc.nextLine();
		
		System.out.print("취미 (,로 공백없이 나열) : ");
		String hobby = sc.nextLine();
		
		// Controller 의 어떤 메소드를 호출하면서
		// 방급 입력받은 값들을 넘기면서 "회원 추가 요청" 보내기
		mc.insertMember(userId, userPwd, userName, gender,
						age, email, phone, address, hobby);
		
	} // insertMember 메소드 끝
	
	public void selectAll() {
		System.out.println("--- 회원 전체 조회 ---");
		// Controller 의 어떤 메소드를 호출하면서
		// 회원 전체 조회 요청
		mc.selectAll();
		
	}
	
	// --------------------------------------------------------------------
	// 서비스 요청 처리 후 사용자가 보게 될 응답화면들
	
	/**
	 * 서비스 요청 성공 시 보게 될 화면
	 * @param message => 성공 시 보여줄 메세지 내용
	 */
	public void displaySuccess(String message) {
		System.out.println("서비스 요청 성공 : " + message);
		
	}
	/**
	 * 서비스 요청 실패 시 보게 될 화면
	 * @param message => 실패 시 보여줄 메시지 내용
	 */
	public void displayFail(String message) {
		System.out.println("서비스 요청 실패 : " + message);
		
	}
	
}
