package com.kh.controller;

import java.util.ArrayList;

import com.kh.model.dao.MemberDao;
import com.kh.model.vo.Member;
import com.kh.view.MemberView;

/*
 *  Controller : View 를 통해서 요청한 기능을 처리하는 담당
 *  			 해당 메소드로 전달된 데이터들을 "가공처리" 한후 
 * 				 Dao 메소드 호출 시 전달
 * 				 Dao 로 부터 반환받은 결과에 따라 사용자가 보게 될
 * 				 View (응답화면) 을 결정
 * 
 * Controller 메소드 코드 flow
 * 1) 매개변수로 전달받은 전달값들을 하나의 VO 객체에 담기 (가공)
 * 2) Dao 단의 메소드를 호출하면서 VO 객체 전달하면서 결과 받기
 * 3) Dao 로 부터 전달받은 결과에 따른 응답 화면을 결정
 * 
 */
public class MemberController {

	/**
	 * 사용자의 회원 추가 요청을 처리해주는 메소드
	 * @param userId
	 * @param userPwd
	 * @param userName
	 * @param gender
	 * @param age
	 * @param email
	 * @param phone
	 * @param address
	 * @param hobby
	 * => 사용자가 회원 추가 요청 시 입력했던 값들
	 */
	public void insertMember(String userId,
							 String userPwd,
							 String userName,
							 String gender,
							 int age,
							 String email,
							 String phone,
							 String address,
							 String hobby) {
		// 1) 전달된 데이터들을 Member 객체로 가공하기
		Member m = new Member(userId,userPwd,userName,gender
							 ,age,email,phone,address,hobby);
		
		// 2) Member 객체를 DAO 의 메소드로 넘기면서 호출
		//    결과값 받기
		int result = new MemberDao().insertMember(m);
		
		// 3) 결과에 따른 응답화면 지정
		if(result > 0) { // 성공했을 경우
			
			// 성공 화면을 띄워줄 것
			// > 성공 화면을 나타내는 메소드 작성 후 호출
			new MemberView().displaySuccess("회원 추가 성공");
		
		}else { // 실패했을 경우
			
			// 실패 화면을 띄워줄 것
			// > 실패 화면을 나타내는 메소드 작성 후 호출
			new MemberView().displayFail("회원 추가 실패");
			
		}
	} // insertMember 메소드 끝
	
	/**
	 * 사용자의 회원 전체 조회 요청을 처리해주는 메소드
	 */
	public void selectAll() {
		
		// 1) 전달된 데이터들을 Member 객체로 가공하기
		// > 전달된 데이터들이 없으므로 패스
		
		// 2) DAO 로 메소드 호출 후 결과 받기
		// > 요청 시 전달값이 없으므로 매개면수 없이 호출
		ArrayList<Member> list = new MemberDao().selectAll();
		// > SELECT 문을 이용한 조회 기능은 크게 2가지로 나뉜다.
		// - 여러행 조회 : 2개 이상의 데이터가 조회될 경우 (ArrayList)
		// - 단일행 조회 : 많아봤자 최대 1개의 데이터가 조회될 경우(VO)
		
	}
	
	
}
